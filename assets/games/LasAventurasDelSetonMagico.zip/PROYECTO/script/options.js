let app = function(){
	let config = {sound:'', dificultat:''};
	
	try {
		config = JSON.parse(localStorage.getItem('config') 
			|| '{"sound":"5","dificultat":"Fàcil"}');
	}
	catch (err){
		localStorage.clear();
	}
	
	function returnToMenu(){
		window.location="../";
	}
	return new Vue({
		el: "#app",
		data: {
			dificulty: config.dificultat,
			sound: config.sound
		},
		computed: {
			conf: function(){
				return {sound:this.sound, dificultat: this.dificulty};
			}
		},
		methods: {
			aplicar: function(){
				localStorage.setItem('config', JSON.stringify(this.conf));
				returnToMenu();
			},
			descartar: function(){
				returnToMenu();
			}
		}
	});
}();