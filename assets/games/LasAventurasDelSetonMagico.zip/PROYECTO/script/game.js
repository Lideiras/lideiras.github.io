 let app = function(){
	let partides;
	let id_partida;
	let indx;
	let start_time = Date.now();
	
	function returnToMenu(){
		window.location="../";
	}
	
	id_partida = sessionStorage.getItem('id_partida', undefined);
	
	if (!id_partida){ 
		returnToMenu();
		return null;
	}
	
	partides = JSON.parse(localStorage.getItem("llistat_partides"));
	
	for (let i = 0; i < partides.length; i++){
		if (id_partida == partides[i].id){
			indx = i;
		}
	}
	
	return new Vue({
		el:'#app',
		data: {
			nom_usuari: partides[indx].name,
			id_partida: partides[indx].id
		},
		created: function(){ // Created és nou
			startGame(partides[indx].info);
		},
		methods:{
			save: function(){
				partides[indx].time += Date.now() - start_time;
				partides[indx].info = saveInfo();
				localStorage.setItem("llistat_partides", JSON.stringify(partides));
				console.log(JSON.stringify(partides));
				alert("Gruardant...");
				returnToMenu();
			},
			menu: function(){
				returnToMenu();
			}
		}
	});
}();