
var config = {
    type: Phaser.AUTO,
    width: 1000,
    height: 600,
	parent: 'joc', // Dir-li on el volem
    physics: {
        default: 'arcade',
        arcade: {
            gravity: { y: 300 },
            debug: false
        }
    },
    scene: [
        intro, nivel1, nivel2
    ]
};

var player;
let partida = null;
var game = null;
var score = 0;
var gameOver = false;
var scoreText;
var camara;
var semillas;
var escudo;
var espada;
var enemigo1;
var enemigos;
var enemigo2;
var max_pasos = 500;


function startGame(p){
	partida = p;
	game = new Phaser.Game(config);
}

function preload ()
{
    this.load.image('enemigo1', '.././assets/enemigo1.png')
}

function collectSemilla (player, semilla)
{
    semilla.disableBody(true, true);			//Hacemos "desaparecer" la semilla cogida
    score += 1;
    scoreText.setText('SEMILLAS: ' + score);

	var spawn = Phaser.Math.Between(0,1)		//Si spawn == 0 entonces se genera un nuevo enemigo

    if (semillas.countActive(true) === 0)
    {
        semillas.children.iterate(function (child) {
            child.enableBody(true, child.x, 0, true, true);
        });
    }
	if(spawn == 0){
		var x = Phaser.Math.Between(100, 1600)
		spawnEnemigo(x, -70, Phaser.Math.Between(-300, 300), 20, 1,1);	//Creamos un nuevo enemigo con los valores aqui descritos
	}

}

function spawnEnemigo (posX, posY, velX, velY, accX, accY){
	//Establecemos las propiedades fisicas del enemigo 1 generado
	enemigo1 = enemigos.create(posX, posY, 'enemigo1').setScale(0.1);
	enemigo1.setBounce(1)
	enemigo1.setCollideWorldBounds(false);
	enemigo1.setVelocity(velX, velY);
	enemigo1.setAcceleration(accX, accY);
	enemigo1.allowGravity = true;
}


function muerto (player, enemigo)
{

    this.physics.pause();		//pausamos todas las fisicas del juego

    player.setTint(0xff0000);	//cambiamos ligeramente los colores del personaje

    player.anims.play('turn');

    gameOver = true;
}


function saveInfo (){ // Guardar partida
	let saveobj = {playerX: player.x, playerY: player.y, score: score};
	saveobj.semillas = [];
	saveobj.enemigos = [];
	saveobj.enemigo2 = [];

	enemigos.children.iterate(function (child) {
		let body = child.body;
		saveobj.enemigos.push({e: body.enable, x: child.x, y: child.y,
						vx: body.velocity.x, vy: body.velocity.y, ax: body.acceleration.x, ay: body.acceleration.y,
						by: body.bounce.y});
	});

	semillas.children.iterate(function (child) {
		let body = child.body;
		saveobj.semillas.push({x: child.x, y: child.y,
						vx: body.velocity.x, vy: body.velocity.y, ax: body.acceleration.x, ay: body.acceleration.y});
	});


	saveobj.enemigo2.push({e: enemigo2.enable, x: enemigo2.x, y: enemigo2.y,
						vx: enemigo2.body.velocity.x, vy: enemigo2.body.velocity.y, ax: enemigo2.body.acceleration.x, ay: enemigo2.body.acceleration.y,
						by: enemigo2.body.bounce.y});

	return saveobj;
}


function enemigoDerrotado(espada, enemy){
	score += 10									//Sumamos la puntuacion extra
	enemy.destroy()								//Eliminamos el enemigo de la partida
}

