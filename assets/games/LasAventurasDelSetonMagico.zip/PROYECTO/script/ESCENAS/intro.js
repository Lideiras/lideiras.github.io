class intro extends Phaser.Scene{
	constructor(){
		super({
			key: "intro"
		});
	};
	
	preload(){
		//Cargamos la image
		this.load.image("texto_intro", ".././assets/INTRO/intro.png");
		
		//barra de carga
		let loadingBar = this.add.graphics({
			fillStyle:{
				color: 0xffffff //blanco
			}
		})
		
		
		//EVENTOS
		for(let i = 0; i < 100; i++){
			this.load.image("texto_intro" + i, ".././assets/INTRO/intro.png");
		}
		
		
		//hacemos que la barra de carga se llene antes de mostrar la imagen
		this.load.on("progress", (percent)=>{
			loadingBar.fillRect(300, 300, 400 * percent, 30);
		})
		
	}
	
	create(){
		
		this.image = this.add.image(500, 300, 'texto_intro');
		
		var text = this.add.text(60, 500, "PRESIONA ESPACIO PARA CONTINUAR", { font: "25px Impact" });
		
		//TECLAS
		this.key_SPACE = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SPACE);
		
	}
	
	update(){
		if(this.key_SPACE.isDown){
			this.scene.start("nivel1");
		}
	}
}




























