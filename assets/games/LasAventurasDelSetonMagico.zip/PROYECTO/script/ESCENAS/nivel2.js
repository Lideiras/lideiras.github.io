class nivel2 extends Phaser.Scene{
	constructor(){
		super({
			key: "nivel2"
		});
	};
				
	preload(){
		
		alert("---- NIVEL 2 ----")
				
		//SPRITES
		this.load.image('cielo', '.././assets/cielo.jpg');
		this.load.spritesheet('player', '.././assets/sprite.png', { frameWidth: 32, frameHeight: 48 });
		this.load.image('semilla', '.././assets/semilla.png');
		
		this.load.image('tiles', '.././assets/NIVEL 2/Tiles.png')
		this.load.tilemapTiledJSON('tilemap2', '.././assets/NIVEL 2/escenario2.json');
		
		this.load.image('escudo', '.././assets/escudo.png')
		this.load.image('espada', '.././assets/espada.png')
		this.load.image('enemigo1', '.././assets/enemigo1.png')
		
	}
	
	create(){
		
		//ESCENARIO
		var cielo = this.add.image(500, 300, 'cielo').setScale(10);
		
		var mappy = this.add.tilemap("tilemap2");
		
		var terrain = mappy.addTilesetImage("mapa3", "tiles")
		
		var layer = mappy.createStaticLayer("suelo", terrain, 0, -90).setScale(3)
		var layerarboles2 = mappy.createStaticLayer("arboles", terrain, 0, -90).setScale(3)
		var layerarboles1 = mappy.createStaticLayer("ESTETICA SUELO", terrain, 0, -90).setScale(3)
		
		layer.setCollisionByProperty({collide: true})
		
		layer.setCollisionBetween(1, 999)
		
		//PERSONAJE
		player = this.physics.add.sprite((partida == undefined)?100:partida.playerX, 
										(partida == undefined)?450:partida.playerY, 'player').setScale(2);
		player.setBounce(0.2);
		
		
		this.anims.create({
			key: 'left',
			frames: this.anims.generateFrameNumbers('player', { start: 0, end: 3 }),
			frameRate: 10,
			repeat: -1
		});

		this.anims.create({
			key: 'turn',
			frames: [ { key: 'player', frame: 4 } ],
			frameRate: 20
		});

		this.anims.create({
			key: 'right',
			frames: this.anims.generateFrameNumbers('player', { start: 5, end: 8 }),
			frameRate: 10,
			repeat: -1
		});
		this.physics.add.collider(player, layer)
		
		//SEMILLAS
		semillas = this.physics.add.group({
			key: 'semilla',
			repeat: 24,
			setXY: { x: 30, y: 50, stepX: 80 },
		});

		//SEMILLAS
		let i = 0;
		semillas.children.iterate(function (child) {

			if (partida != undefined){
				child.x = partida.semillas[i].x;
				child.y = partida.semillas[i].y;
				if (partida.semillas[i].e == false) child.disableBody(true, true);
					i++;
			}
			else{
				child.setBounceY(Phaser.Math.FloatBetween(0, 0.1));
			}
		});
		this.physics.add.collider(semillas, layer);
		this.physics.add.overlap(player, semillas, collectSemilla, null, this);

		
		//ENEMIGO1
		enemigos = this.physics.add.group();
	
		if (partida != undefined){
			for (let j = 0; j < partida.enemigos.length; j++){
				let b = partida.enemigos[j];
				spawnEnemigo(b.x, b.y, b.vx, b.vy, b.ax, b.ay);
			}
		}
		
		this.physics.add.collider(player, enemigos, muerto, null, this);
		
		//ENEMIGO2
		enemigo2 = this.physics.add.sprite(2000 , 10, 'enemigo2').setScale(2.5)
		
		this.anims.create({
			key: 'izq',
			frames: this.anims.generateFrameNumbers('enemigo2', { start: 0, end: 7 }),
			frameRate: 10,
			repeat: -1
		});

		this.anims.create({
			key: 'idle',
			frames: [ { key: 'enemigo2', frame: 4 } ],
			frameRate: 20
		});

		this.anims.create({
			key: 'der',
			frames: this.anims.generateFrameNumbers('enemigo2', { start: 9, end: 16 }),
			frameRate: 10,
			repeat: -1
		});		
		
		//VALORES DE MOVIMIENTO INICIALES
		enemigo2.direccion = Phaser.Math.RND.sign()
		enemigo2.setVelocityX(Phaser.Math.Between(175, 250) * enemigo2.direccion)
		enemigo2.stepCount = Phaser.Math.Between(0, max_pasos);
		enemigo2.setBounce(.5);
		enemigo2.setCollideWorldBounds(false);
		enemigo2.body.setFrictionX(0)
		
		//TECLAS
		this.key_W = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.W);
		this.key_A = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.A);
		this.key_D = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.D);
		this.key_O = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.O);
		this.key_P = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.P);
		this.key_1 = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.ONE);
		this.key_2 = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.TWO);
		
		//CAMARA
		camara = this.cameras.main.startFollow(player)
		camara.setBounds(0,0, layer.displayWidth, layer.displayHeight)
		camara.setFollowOffset(0, 120)
		camara.setDeadzone(50, 200);
		camara.setLerp(0.5, 0.5);
		
		//SCORE		
		if (partida != undefined) score = partida.score;
		scoreText = this.add.text(30, 30, 'SEMILLAS: ' + score, { fontSize: '40px', color: 'Black', backgroundColor: 'White' });
		scoreText.setScrollFactor(0)
		
		//HABILIDAD 1
		escudo = this.physics.add.sprite(player.x, player.y, 'escudo').setScale(2)
		escudo.body.allowGravity = false
		escudo.setImmovable(true)
		
		this.physics.add.collider(enemigos, escudo)
		this.physics.add.collider(escudo, enemigo2)
		
		//HABILIDAD 2
		espada = this.physics.add.sprite(player.x, player.y, 'espada')
		espada.flipY = true
		espada.body.allowGravity = false
		
		this.physics.add.overlap(enemigos, espada, enemigoDerrotado, null, this);
		this.physics.add.overlap(espada, enemigo2, enemigoDerrotado, null, this);

		
		
		this.physics.add.collider(enemigos, layer)
		this.physics.add.collider(enemigo2, layer)
		this.physics.add.collider(player, enemigo2, muerto, null, this);
		
		
	}
	
	
	update(){
		
		//KEY HANDLERS		
		if (this.key_A.isDown)
		{
			player.setVelocityX(-160);

			player.anims.play('left', true);
		}
		else if (this.key_D.isDown)
		{
			player.setVelocityX(160);

			player.anims.play('right', true);
		}
		
		else
		{
			player.setVelocityX(0);

			player.anims.play('turn');
			
		}
		
		if (this.key_W.isDown && player.body.onFloor())
		{
			player.setVelocityY(-350);
		}
		
		if(this.key_O.isDown && this.key_P.isUp){
			escudo.body.setEnable = true
			escudo.visible = true
			escudo.x = player.x
			escudo.y = player.y			
		}
		else{
			escudo.x = 1000
			escudo.y = 1000
			escudo.visible = false
			
		}
		
		if(this.key_P.isDown && this.key_O.isUp){
			espada.visible = true				
			if(player.anims.currentAnim.key == 'right'){
				espada.flipX = false
				espada.x = player.x + 40
				espada.y = player.y + 15
			}
			
			else if(player.anims.currentAnim.key == 'left'){
				espada.flipX = true
				espada.visible = true
				espada.x = player.x - 40
				espada.y = player.y + 15
			}
			else{
				espada.visible = false
			}
		}
		else{
			espada.visible = false
			espada.x = 1000
			espada.y = 1000
		}
		
		if (Phaser.Input.Keyboard.JustDown(this.key_1)){
			console.log('TECLA 1 PULSADA -> REINICIANDO ESCENA')
			this.scene.stop()
			this.scene.restart()
		}
		if (Phaser.Input.Keyboard.JustDown(this.key_2)){
			console.log('TECLA 2 PULSADA -> SIGUIENTE ESCENA')
			this.scene.stop()
			this.scene.start("nivel2");
		}
		
		
		//MOVIMIENTO DEL ENEMIGO SETA
		if(enemigo2.active){
			enemigo2.stepCount++;
			if (enemigo2.stepCount > max_pasos) {
				enemigo2.direccion = Phaser.Math.RND.sign()
				enemigo2.setVelocityX(Phaser.Math.Between(125, 175) * enemigo2.direccion);
				enemigo2.stepCount = 0;
				console.log("Pasos terminados")
				console.log(enemigo2.body.velocity.x)
				console.log(enemigo2.direccion)
			}
			
			
			if(enemigo2.body.facing == Phaser.Physics.Arcade.FACING_RIGHT){
				enemigo2.anims.play('der', true)
			}
			else if(enemigo2.body.facing == Phaser.Physics.Arcade.FACING_LEFT){
				enemigo2.anims.play('izq', true)
			}
			else{
				enemigo2.anims.play('idle')
			}
		}
	}
}