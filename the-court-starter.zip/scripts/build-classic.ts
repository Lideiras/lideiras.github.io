import { mkdirSync, writeFileSync } from 'node:fs';
import { content } from '../src/data/content';
import type { L10n } from '../src/i18n';

const esc = (s: string): string => s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c] as string);
const safe = (u: string): string => (/^(https?:|mailto:)/i.test(u) ? u : '#');
/** Cada texto se emite en ambos idiomas; el CSS oculta el que no toca. */
const b = (v: L10n): string => `<span lang="es">${esc(v.es)}</span><span lang="en">${esc(v.en)}</span>`;
const L = (es: string, en: string): L10n => ({ es, en });

const html = `<!doctype html>
<html lang="es" data-l="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>${esc(content.person.name)} · ${esc(content.person.role.es)} / ${esc(content.person.role.en)}</title>
<meta name="description" content="${esc(content.person.tagline.es)} ${esc(content.person.tagline.en)}">
<link rel="canonical" href="/classic/">
<style>
:root{color-scheme:dark;--a:#ff6a1a}
html[data-l=es] [lang=en],html[data-l=en] [lang=es]{display:none}
body{margin:0;font:16px/1.6 system-ui,sans-serif;background:#0b1020;color:#f1f5f9}
main{max-width:860px;margin:0 auto;padding:2rem 1rem 4rem}
h1{font-size:2.6rem;margin:.2rem 0}h2{border-bottom:2px solid var(--a);padding-bottom:.3rem;margin-top:2.5rem}
a{color:var(--a)}.muted{color:#94a3b8}.tag{display:inline-block;background:#1e293b;border-radius:99px;padding:.1rem .6rem;margin:0 .3rem .3rem 0;font-size:.85rem}
article{border:1px solid #243049;border-radius:12px;padding:1rem;margin:1rem 0}
nav{display:flex;gap:1rem;flex-wrap:wrap;justify-content:space-between}
button{background:var(--a);color:#fff;border:0;border-radius:8px;padding:.4rem .9rem;font-weight:700;cursor:pointer}
</style>
</head>
<body>
<main>
<nav><a href="/">${b(L('🏀 Jugar la versión interactiva', '🏀 Play the interactive version'))}</a><button id="lang" type="button">EN / ES</button></nav>
<header><h1>${esc(content.person.name)}</h1><p>${b(content.person.role)} · ${esc(content.person.location)}</p><p class="muted">${b(content.person.tagline)}</p></header>

<section id="about"><h2>${b(L('Sobre mí', 'About me'))}</h2>${content.about.paragraphs.map((p) => `<p>${b(p)}</p>`).join('')}</section>

<section id="projects"><h2>${b(L('Proyectos', 'Projects'))}</h2>${content.projects
  .map(
    (p) => `<article><h3>${esc(p.title)} <span class="muted">${p.year}</span></h3><p>${b(p.summary)}</p><p>${p.stack.map((s) => `<span class="tag">${esc(s)}</span>`).join('')}</p><p>${p.links.map((l) => `<a href="${esc(safe(l.url))}" rel="noopener noreferrer">${b(l.label)}</a>`).join(' · ')}</p></article>`,
  )
  .join('')}</section>

<section id="skills"><h2>Skills</h2>${content.skills
  .map((g) => `<h3>${b(g.name)}</h3><p>${g.items.map((i) => `<span class="tag">${esc(i.name)} ${i.level}/5</span>`).join('')}</p>`)
  .join('')}</section>

<section id="experience"><h2>${b(L('Experiencia y estudios', 'Experience and education'))}</h2>${content.timeline
  .map((x) => `<article><h3>${b(x.title)}</h3><p class="muted">${esc(x.org)} · ${esc(x.start)} – ${x.end ? esc(x.end) : b(L('Actualidad', 'Present'))}</p><p>${b(x.description)}</p></article>`)
  .join('')}</section>

<section id="contact"><h2>${b(L('Contacto', 'Contact'))}</h2><p><a href="mailto:${esc(content.person.email)}">${esc(content.person.email)}</a></p><p>${content.person.social
  .map((l) => `<a href="${esc(safe(l.url))}" rel="noopener noreferrer">${b(l.label)}</a>`)
  .join(' · ')}</p></section>
</main>
<script>
(function(){var r=document.documentElement,s;try{s=localStorage.getItem('court.lang')}catch(e){}
var l=s||((navigator.language||'es').slice(0,2)==='en'?'en':'es');r.dataset.l=l;r.lang=l;
document.getElementById('lang').onclick=function(){l=l==='es'?'en':'es';r.dataset.l=l;r.lang=l;try{localStorage.setItem('court.lang',l)}catch(e){}}})();
</script>
</body>
</html>
`;

mkdirSync('public/classic', { recursive: true });
writeFileSync('public/classic/index.html', html);
console.log('✓ public/classic/index.html generado desde content.ts');
