import * as THREE from 'three';
import { content, type SectionId } from '../data/content';
import { t } from '../i18n';
import { Hud } from '../ui/hud';
import { PanelManager, sectionKey } from '../ui/panels';
import { Sfx } from './audio';
import { Ball } from './ball';
import { buildCourt } from './builders/court';
import { animateHuman, buildHuman, poseShoot } from './builders/human';
import { buildBench, buildHoop, buildTunnel, buildZoneRing, createBallMesh } from './builders/props';
import { buildInterviewSet } from './builders/tv';
import {
  CAMERA, INTERVIEW, PLAYER, RIM, SECTION_IDS, SHOOT_RANGE, ZONES, rimX, type Side, type Zone,
} from './config';
import { Input } from './input';
import { applyShotError, evaluateMeter, meterAt, solveShot } from './shot';

type Mode = 'play' | 'panel' | 'interview';
export interface GameHandle { start(): void; dispose(): void }

const clamp = (v: number, a: number, b: number): number => Math.min(b, Math.max(a, v));
const lerpAngle = (a: number, b: number, k: number): number => a + Math.atan2(Math.sin(b - a), Math.cos(b - a)) * k;
const nextFrame = (): Promise<void> => new Promise((r) => requestAnimationFrame(() => r()));

function loadSet(key: string): Set<SectionId> {
  try {
    const raw = JSON.parse(localStorage.getItem(key) ?? '[]') as unknown;
    return new Set((Array.isArray(raw) ? raw : []).filter((x): x is SectionId => SECTION_IDS.includes(x as SectionId)));
  } catch {
    return new Set();
  }
}
function saveSet(key: string, s: Set<SectionId>): void {
  try {
    localStorage.setItem(key, JSON.stringify([...s]));
  } catch {
    /* ignorar */
  }
}

export async function createGame(opts: { canvas: HTMLCanvasElement; onProgress: (p: number) => void }): Promise<GameHandle> {
  const { canvas, onProgress } = opts;
  const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const coarse = matchMedia('(pointer: coarse)').matches;

  onProgress(0.05);
  await document.fonts.load('48px "Bebas Neue"').catch(() => undefined);

  // ───────── Renderer, escena, cámara, luces
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
  let pixelRatio = Math.min(window.devicePixelRatio, coarse ? 1.5 : 2);
  renderer.setPixelRatio(pixelRatio);
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x0b1020);
  scene.fog = new THREE.Fog(0x0b1020, 32, 75);
  const camera = new THREE.PerspectiveCamera(CAMERA.fov, 1, 0.1, 120);

  scene.add(new THREE.HemisphereLight(0xffffff, 0x334155, 0.9));
  const sun = new THREE.DirectionalLight(0xffffff, 2.2);
  sun.position.set(-8, 18, 10);
  sun.castShadow = true;
  sun.shadow.mapSize.set(coarse ? 1024 : 2048, coarse ? 1024 : 2048);
  Object.assign(sun.shadow.camera, { left: -20, right: 20, top: 16, bottom: -16, near: 1, far: 50 });
  sun.shadow.bias = -0.0005;
  scene.add(sun);
  onProgress(0.2);
  await nextFrame();

  // ───────── Mundo
  scene.add(buildCourt(content.person.initials, renderer.capabilities.getMaxAnisotropy()));
  scene.add(buildHoop(-1), buildHoop(1), buildBench(), buildTunnel());
  const set = buildInterviewSet();
  scene.add(set.group);

  const rings: THREE.Mesh[] = [];
  for (const z of ZONES) {
    if (z.kind === 'shoot') continue;
    const ring = buildZoneRing(z.x, z.z, z.radius);
    rings.push(ring);
    scene.add(ring);
  }
  onProgress(0.55);
  await nextFrame();

  // ───────── Jugador y balón
  const player = buildHuman({
    skin: 0xf1c27d, hair: 0x2b1d12, jersey: 0xff6a1a, shorts: 0x111827, shoes: 0xffffff, number: content.person.jerseyNumber,
  });
  scene.add(player.root);
  const pos = player.root.position;
  let rotY = 0;

  const sfx = new Sfx();
  const ballMesh = createBallMesh();
  scene.add(ballMesh);
  const ball = new Ball(ballMesh, {
    score: onScore,
    rim: () => sfx.rim(),
    board: () => sfx.board(),
    bounce: (v) => sfx.bounce(v),
  });

  // ───────── UI y estado
  const uiRoot = document.getElementById('ui')!;
  let mode: Mode = 'play';
  const visited = loadSet('court.visited');
  const unlocked = loadSet('court.unlocked');
  const input = new Input();
  const panels = new PanelManager(uiRoot, () => setMode('play'));
  const hud = new Hud(
    uiRoot,
    {
      onMenuSelect: (id) => openSection(id, false),
      onToggleMute: () => sfx.toggleMute(),
    },
    sfx.muted,
  );
  if (coarse) hud.mountTouch(input);
  canvas.setAttribute('aria-label', t('aria_game'));
  window.addEventListener('langchange', () => canvas.setAttribute('aria-label', t('aria_game')));
  hud.setProgress(visited.size);

  for (const z of ZONES) hud.addLabel(z.id, sectionKey(z.id));

  function setMode(m: Mode): void {
    mode = m;
    document.body.dataset.mode = m;
    input.setEnabled(m === 'play');
    if (m === 'play') canvas.focus({ preventScroll: true });
  }

  // ───────── Lógica de juego
  let charging = false;
  let chargeT = 0;
  let flick = 0;
  let missStreak = 0;
  let mvpShown = false;

  function nearestSide(): Side {
    return Math.abs(pos.x - rimX(-1)) <= Math.abs(pos.x - rimX(1)) ? -1 : 1;
  }
  const zoneFor = (side: Side): Zone => ZONES.find((z) => z.side === side)!;

  function markVisited(id: SectionId): void {
    visited.add(id);
    saveSet('court.visited', visited);
    hud.setProgress(visited.size);
  }

  function openSection(id: SectionId, fromZone: boolean): void {
    markVisited(id);
    sfx.click();
    setMode(id === 'contact' && fromZone ? 'interview' : 'panel');
    if (mode === 'interview') {
      pos.set(INTERVIEW.playerSpot[0], 0, INTERVIEW.playerSpot[1]);
      rotY = 0; // mira hacia +Z (el reportero)
      player.root.rotation.y = rotY;
    }
    panels.open(id);
    if (!mvpShown && visited.size === SECTION_IDS.length) {
      mvpShown = true;
      window.setTimeout(() => hud.toast(t('mvp'), 4500), 600);
    }
  }

  function onScore(side: Side): void {
    sfx.swish();
    missStreak = 0;
    const zone = zoneFor(side);
    if (unlocked.has(zone.id)) {
      hud.toast(t('shot_basket'));
      return;
    }
    unlocked.add(zone.id);
    saveSet('court.unlocked', unlocked);
    sfx.cheer();
    hud.toast(`${t('unlocked')}: ${t(sectionKey(zone.id))}`, 3000);
    window.setTimeout(() => mode === 'play' && openSection(zone.id, false), 1300);
  }

  function shoot(meter: number): void {
    const side = nearestSide();
    const rim = new THREE.Vector3(rimX(side), RIM.y, 0);
    const from = new THREE.Vector3(pos.x + Math.sin(rotY) * 0.2, 2.15, pos.z + Math.cos(rotY) * 0.2);
    const sol = solveShot(from, rim) ?? { vx: 0, vy: 6, vz: 0, t: 1, angleDeg: 90 };
    const { e, perfect } = evaluateMeter(meter);
    const assist = missStreak >= 3 ? 0.4 : 0.85; // tras 3 fallos el juego se vuelve más permisivo
    const v = applyShotError(sol, e, assist, Math.random);
    ball.launch(from, new THREE.Vector3(v.x, v.y, v.z));
    sfx.release();
    flick = 0.35;
    if (perfect) hud.toast(t('shot_perfect'), 1200);
  }

  const tmp = new THREE.Vector3();
  function placeHeldBall(time: number, speed01: number): void {
    const f = tmp.set(Math.sin(rotY), 0, Math.cos(rotY));
    const side = { x: Math.cos(rotY), z: -Math.sin(rotY) }; // +X local del jugador
    let x = pos.x;
    let y: number;
    let z = pos.z;
    if (charging) {
      y = 1.9 + Math.min(chargeT, 0.6) * 0.5;
      x += f.x * 0.2;
      z += f.z * 0.2;
    } else if (speed01 > 0.1) {
      y = 0.14 + Math.abs(Math.sin(time * 11)) * 0.9;
      x += f.x * 0.45 + side.x * 0.28;
      z += f.z * 0.45 + side.z * 0.28;
    } else {
      y = 1.2;
      x += f.x * 0.42;
      z += f.z * 0.42;
    }
    ball.pos.set(x, y, z);
    ball.object.position.copy(ball.pos);
  }

  // ───────── Cámara
  const camGoal = new THREE.Vector3();
  const lookGoal = new THREE.Vector3();
  const lookNow = new THREE.Vector3();
  let dist = 1;
  function updateCamera(dt: number, snap = false): void {
    if (mode === 'interview') {
      camGoal.set(...INTERVIEW.cameraPos);
      lookGoal.set(...INTERVIEW.cameraLook);
    } else {
      const tx = clamp(pos.x, -CAMERA.clampX, CAMERA.clampX);
      const tz = clamp(pos.z, CAMERA.minZ, CAMERA.maxZ);
      lookGoal.set(tx, 0.8, tz);
      camGoal.set(tx + CAMERA.offset[0] * dist, CAMERA.offset[1] * dist, tz + CAMERA.offset[2] * dist);
    }
    const k = snap || reduced ? 1 : 1 - Math.exp(-CAMERA.lerp * dt);
    camera.position.lerp(camGoal, k);
    lookNow.lerp(lookGoal, k);
    camera.lookAt(lookNow);
  }

  function resize(): void {
    const w = window.innerWidth;
    const h = window.innerHeight;
    renderer.setPixelRatio(pixelRatio);
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    dist = clamp(1.5 / camera.aspect, 1, 2.4); // en vertical se aleja para ver más cancha
    camera.updateProjectionMatrix();
  }
  window.addEventListener('resize', resize);
  resize();
  onProgress(0.85);

  // ───────── Bucle
  const proj = new THREE.Vector3();
  const clock = new THREE.Clock();
  let raf = 0;
  let slowFrames = 0;

  function update(dt: number, time: number): void {
    const playing = mode === 'play';
    let speed01 = 0;

    if (playing) {
      const wants = input.shootHeld && ball.state === 'held';
      if (wants && !charging) {
        charging = true;
        chargeT = 0;
      }
      if (charging) {
        chargeT += dt;
        const side = nearestSide();
        rotY = lerpAngle(rotY, Math.atan2(rimX(side) - pos.x, -pos.z), 1 - Math.exp(-14 * dt));
        hud.showMeter(meterAt(chargeT));
        if (!input.shootHeld) {
          shoot(meterAt(chargeT));
          charging = false;
          hud.showMeter(null);
        }
      } else {
        const mv = input.move();
        const len = Math.hypot(mv.x, mv.z);
        if (len > 0.05) {
          const k = Math.min(1, len);
          const dx = mv.x / len;
          const dz = mv.z / len;
          pos.x = clamp(pos.x + dx * PLAYER.speed * k * dt, PLAYER.bounds.minX, PLAYER.bounds.maxX);
          pos.z = clamp(pos.z + dz * PLAYER.speed * k * dt, PLAYER.bounds.minZ, PLAYER.bounds.maxZ);
          rotY = lerpAngle(rotY, Math.atan2(dx, dz), 1 - Math.exp(-14 * dt));
          speed01 = k;
        }
      }
    } else if (charging) {
      charging = false;
      hud.showMeter(null);
    }
    player.root.rotation.y = rotY;

    // Animación del jugador
    animateHuman(player, time, speed01, ball.state === 'held' && !charging);
    if (charging) poseShoot(player, Math.min(chargeT / 0.6, 1));
    if (flick > 0) {
      flick -= dt;
      poseShoot(player, 1);
    }

    // Balón
    if (ball.state === 'held') placeHeldBall(time, speed01);
    else {
      ball.step(dt);
      if (ball.settled) {
        if (!ball.scored) missStreak++;
        ball.state = 'held';
      }
    }

    // Zonas, avisos e interacción
    let active: Zone | null = null;
    let best = Infinity;
    for (const z of ZONES) {
      const d = Math.hypot(pos.x - z.x, pos.z - z.z);
      const usable = z.kind !== 'shoot' || unlocked.has(z.id);
      if (playing && usable && d <= z.radius && d < best) {
        best = d;
        active = z;
      }
    }
    if (playing && active) {
      hud.setPrompt(`${coarse ? t('hint_interact_touch') : t('hint_interact')} · ${t(sectionKey(active.id))}`);
      if (input.consumeInteract()) openSection(active.id, true);
    } else {
      input.consumeInteract();
      const side = nearestSide();
      const near = Math.abs(pos.x - rimX(side)) <= SHOOT_RANGE && !unlocked.has(zoneFor(side).id);
      hud.setPrompt(playing && near && ball.state === 'held' && !charging ? (coarse ? t('hint_shoot_touch') : t('hint_shoot')) : null);
    }

    // Decorado vivo
    for (const r of rings) r.scale.setScalar(1 + Math.sin(time * 3) * 0.04);
    animateHuman(set.reporter, time, 0, false);
    animateHuman(set.operator, time, 0, false);
    set.reporter.armR.rotation.x = mode === 'interview' ? -1.45 : -1.15;
    set.tally.visible = mode === 'interview' || Math.floor(time * 1.5) % 2 === 0;
    (set.onAir.material as THREE.MeshStandardMaterial).emissiveIntensity = mode === 'interview' ? 1.6 : 0.2;

    updateCamera(dt);

    // Etiquetas flotantes (proyección mundo → pantalla)
    const w = window.innerWidth;
    const h = window.innerHeight;
    for (const z of ZONES) {
      proj.set(z.x, z.kind === 'shoot' ? 4.6 : 2.5, z.z).project(camera);
      hud.placeLabel(z.id, (proj.x * 0.5 + 0.5) * w, (-proj.y * 0.5 + 0.5) * h, proj.z < 1 && mode !== 'interview');
    }
  }

  function frame(): void {
    raf = requestAnimationFrame(frame);
    const dt = Math.min(clock.getDelta(), 1 / 20);
    update(dt, clock.elapsedTime);
    renderer.render(scene, camera);

    // Calidad adaptativa: si va lento, baja la resolución de render
    slowFrames = dt > 1 / 24 ? slowFrames + 1 : Math.max(0, slowFrames - 1);
    if (slowFrames > 90 && pixelRatio > 1) {
      pixelRatio = Math.max(1, pixelRatio - 0.25);
      slowFrames = 0;
      resize();
    }
  }

  const onVisibility = (): void => {
    if (document.hidden) cancelAnimationFrame(raf);
    else {
      clock.getDelta();
      raf = requestAnimationFrame(frame);
    }
  };
  document.addEventListener('visibilitychange', onVisibility);

  onProgress(1);
  return {
    start() {
      sfx.unlock();
      setMode('play');
      updateCamera(0, true);
      hud.toast(coarse ? t('welcome_touch') : t('welcome'), 6000);
      clock.start();
      raf = requestAnimationFrame(frame);
    },
    dispose() {
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', resize);
      document.removeEventListener('visibilitychange', onVisibility);
      input.dispose();
      renderer.dispose();
    },
  };
}

