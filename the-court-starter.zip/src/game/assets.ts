import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';

/** Gestor de progreso de carga compartido (solo se usa si añades modelos .glb). */
export function createLoadingManager(onProgress: (p: number) => void): THREE.LoadingManager {
  const m = new THREE.LoadingManager();
  m.onProgress = (_url, loaded, total) => onProgress(total ? loaded / total : 1);
  return m;
}

export interface LoadedModel { scene: THREE.Group; animations: THREE.AnimationClip[] }

/**
 * Carga un .glb. Si falla (404, red…) devuelve null para que el llamador
 * conserve la versión procedural. Nunca rompe el arranque del juego.
 */
export async function loadModel(url: string, manager?: THREE.LoadingManager): Promise<LoadedModel | null> {
  try {
    const gltf = await new GLTFLoader(manager).loadAsync(url);
    gltf.scene.traverse((o) => {
      if ((o as THREE.Mesh).isMesh) {
        o.castShadow = true;
        o.receiveShadow = true;
      }
    });
    return { scene: gltf.scene, animations: gltf.animations };
  } catch (err) {
    console.warn(`[assets] no se pudo cargar ${url}; se usa el modelo procedural`, err);
    return null;
  }
}
