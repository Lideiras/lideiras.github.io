import { G, METER_HZ, SWEET_SPOT } from './config';

export interface V3 { x: number; y: number; z: number }
export interface ShotSolution { vx: number; vy: number; vz: number; t: number; angleDeg: number }

/**
 * Velocidad inicial para ir de `from` a `rim` siguiendo una parábola.
 * Prueba varios ángulos y se queda con el primero que llega al aro DESCENDIENDO
 * (si llegara subiendo, el balón nunca podría entrar).
 */
export function solveShot(from: V3, rim: V3, angles: number[] = [55, 62, 70, 78]): ShotSolution | null {
  const dx = rim.x - from.x;
  const dz = rim.z - from.z;
  const d = Math.hypot(dx, dz);
  const h = rim.y - from.y;
  if (d < 0.01) return null;

  for (const angleDeg of angles) {
    const th = (angleDeg * Math.PI) / 180;
    const denom = 2 * Math.cos(th) ** 2 * (d * Math.tan(th) - h);
    if (denom <= 0) continue;
    const v = Math.sqrt((G * d * d) / denom);
    const vh = v * Math.cos(th);
    const vy = v * Math.sin(th);
    const t = d / vh;
    if (vy - G * t >= 0) continue; // llega subiendo: descartar
    return { vx: (vh * dx) / d, vy, vz: (vh * dz) / d, t, angleDeg };
  }
  return null;
}

/** Medidor triangular 0→1→0 con METER_HZ barridos completos por segundo. */
export function meterAt(seconds: number): number {
  const p = (seconds * METER_HZ) % 2;
  return p < 1 ? p : 2 - p;
}

/** e ∈ [-1, 1]; 0 = centro exacto de la zona verde. */
export function evaluateMeter(m: number): { e: number; perfect: boolean } {
  const e = (m - 0.5) * 2;
  return { e, perfect: Math.abs(e) <= SWEET_SPOT };
}

/**
 * Aplica el error de timing a la solución ideal.
 * - Dentro de la zona verde (|e| <= SWEET_SPOT) el error es 0: canasta garantizada.
 * - Fuera, el error crece linealmente hasta 1 en los extremos del medidor.
 * - assist ∈ [0, 1]: 1 = error completo, 0 = siempre perfecto.
 */
export function applyShotError(sol: ShotSolution, e: number, assist: number, rnd: () => number): V3 {
  const mag = Math.max(0, Math.abs(e) - SWEET_SPOT) / (1 - SWEET_SPOT);
  const eEff = Math.sign(e) * mag;
  const speedScale = 1 + eEff * 0.06 * assist;
  const yaw = (rnd() - 0.5) * 0.03 * mag * assist;
  const cos = Math.cos(yaw);
  const sin = Math.sin(yaw);
  const vx = sol.vx * speedScale;
  const vz = sol.vz * speedScale;
  return { x: vx * cos - vz * sin, y: sol.vy * speedScale, z: vx * sin + vz * cos };
}
