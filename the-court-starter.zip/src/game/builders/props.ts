import * as THREE from 'three';
import { BALL, COURT, RIM, boardX, rimX, type Side } from '../config';
import { box, canvasTexture, cylBetween, mat } from './util';

/** Canasta completa: poste, brazo, tablero, aro y red. Medidas FIBA (aro a 3.05 m). */
export function buildHoop(side: Side): THREE.Group {
  const g = new THREE.Group();
  const bx = boardX(side);
  const poleX = side * (COURT.halfL + 0.6);

  const pole = box(0.18, 3.7, 0.18, 0x2b2f3a);
  pole.position.set(poleX, 1.85, 0);
  const arm = cylBetween(new THREE.Vector3(poleX, 3.4, 0), new THREE.Vector3(bx, 3.4, 0), 0.06, 0x2b2f3a);

  const board = new THREE.Mesh(
    new THREE.BoxGeometry(0.05, 1.05, 1.8),
    new THREE.MeshStandardMaterial({ color: 0xffffff, transparent: true, opacity: 0.85, roughness: 0.2 }),
  );
  board.position.set(bx, 3.425, 0);
  board.castShadow = true;
  const square = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.45, 0.59), new THREE.MeshBasicMaterial({ color: 0xff5a1f, wireframe: true }));
  square.position.set(bx - side * 0.001, 3.25, 0);

  const rim = new THREE.Mesh(
    new THREE.TorusGeometry(RIM.radius, RIM.tube * 1.6, 8, 24),
    new THREE.MeshStandardMaterial({ color: 0xff5a1f, roughness: 0.4 }),
  );
  rim.rotation.x = Math.PI / 2;
  rim.position.set(rimX(side), RIM.y, 0);
  rim.castShadow = true;

  const net = new THREE.Mesh(
    new THREE.CylinderGeometry(RIM.radius, 0.13, 0.45, 12, 3, true),
    new THREE.MeshBasicMaterial({ color: 0xffffff, wireframe: true, transparent: true, opacity: 0.8 }),
  );
  net.position.set(rimX(side), RIM.y - 0.225, 0);

  g.add(pole, arm, board, square, rim, net);
  return g;
}

export function buildBench(): THREE.Group {
  const g = new THREE.Group();
  const seat = box(5, 0.1, 0.55, 0x8b5a2b);
  seat.position.set(0, 0.5, 9.7);
  const back = box(5, 0.5, 0.08, 0x8b5a2b);
  back.position.set(0, 0.85, 9.95);
  for (const x of [-2.2, 2.2]) {
    const leg = box(0.1, 0.5, 0.5, 0x2b2f3a);
    leg.position.set(x, 0.25, 9.7);
    g.add(leg);
  }
  const bag = box(0.7, 0.35, 0.4, 0xff6a1a);
  bag.position.set(1.4, 0.72, 9.7);
  const towel = box(0.5, 0.06, 0.3, 0xf8fafc);
  towel.position.set(-1.2, 0.58, 9.7);
  g.add(seat, back, bag, towel);
  return g;
}

/** Puerta del túnel de vestuarios, en el lateral lejano de la pista. */
export function buildTunnel(): THREE.Group {
  const g = new THREE.Group();
  const frame = box(3.4, 3.0, 0.6, 0x1b2233);
  frame.position.set(-10, 1.5, -9.9);
  const opening = new THREE.Mesh(new THREE.PlaneGeometry(2.0, 2.4), new THREE.MeshBasicMaterial({ color: 0x04060a }));
  opening.position.set(-10, 1.2, -9.59);
  const lightTex = canvasTexture(128, 32, (c) => {
    c.fillStyle = '#16a34a';
    c.fillRect(0, 0, 128, 32);
    c.fillStyle = '#ffffff';
    c.font = 'bold 22px sans-serif';
    c.textAlign = 'center';
    c.textBaseline = 'middle';
    c.fillText('EXIT', 64, 17);
  });
  const sign = new THREE.Mesh(new THREE.PlaneGeometry(0.8, 0.2), new THREE.MeshBasicMaterial({ map: lightTex }));
  sign.position.set(-10, 2.75, -9.58);
  g.add(frame, opening, sign);
  return g;
}

/** Anillo luminoso en el suelo que marca una zona interactiva. */
export function buildZoneRing(x: number, z: number, radius: number): THREE.Mesh {
  const ring = new THREE.Mesh(
    new THREE.RingGeometry(radius - 0.08, radius, 48),
    new THREE.MeshBasicMaterial({ color: 0xff6a1a, transparent: true, opacity: 0.85, side: THREE.DoubleSide }),
  );
  ring.rotation.x = -Math.PI / 2;
  ring.position.set(x, 0.03, z);
  return ring;
}

/** Balón: esfera naranja con costuras dibujadas en la textura. */
export function createBallMesh(): THREE.Mesh {
  const tex = canvasTexture(256, 128, (g) => {
    g.fillStyle = '#e8651a';
    g.fillRect(0, 0, 256, 128);
    g.strokeStyle = '#1a1208';
    g.lineWidth = 4;
    for (const x of [0, 64, 128, 192]) {
      g.beginPath();
      g.moveTo(x, 0);
      g.lineTo(x, 128);
      g.stroke();
    }
    g.beginPath();
    g.moveTo(0, 64);
    g.lineTo(256, 64);
    g.stroke();
  });
  const m = new THREE.Mesh(
    new THREE.SphereGeometry(BALL.radius * BALL.visualScale, 16, 12),
    new THREE.MeshStandardMaterial({ map: tex, roughness: 0.7 }),
  );
  m.castShadow = true;
  return m;
}

export { mat };
