import * as THREE from 'three';
import { buildHuman, type HumanRig } from './human';
import { box, canvasTexture, cylBetween, mat } from './util';

export interface InterviewSet {
  group: THREE.Group;
  reporter: HumanRig;
  operator: HumanRig;
  tally: THREE.Mesh;
  onAir: THREE.Mesh;
}

/** Cámara de TV de estudio sobre trípode. Apunta hacia +Z local. */
export function buildTvCamera(): { group: THREE.Group; tally: THREE.Mesh } {
  const g = new THREE.Group();
  const body = box(0.46, 0.38, 0.8, 0x1f2937);
  body.position.set(0, 1.5, 0);
  const lens = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.17, 0.4, 12), mat(0x0b0f19));
  lens.rotation.x = Math.PI / 2;
  lens.position.set(0, 1.5, 0.6);
  lens.castShadow = true;
  const hood = new THREE.Mesh(new THREE.CylinderGeometry(0.21, 0.17, 0.14, 12, 1, true), mat(0x111827));
  hood.rotation.x = Math.PI / 2;
  hood.position.set(0, 1.5, 0.84);
  const viewfinder = box(0.2, 0.2, 0.3, 0x111827);
  viewfinder.position.set(0.3, 1.58, -0.05);
  const head = box(0.18, 0.18, 0.18, 0x374151);
  head.position.set(0, 1.28, 0);

  for (let i = 0; i < 3; i++) {
    const a = (i * Math.PI * 2) / 3;
    g.add(cylBetween(new THREE.Vector3(0, 1.3, 0), new THREE.Vector3(Math.sin(a) * 0.65, 0, Math.cos(a) * 0.65), 0.025, 0x374151));
  }

  const tally = new THREE.Mesh(new THREE.SphereGeometry(0.045, 8, 6), new THREE.MeshBasicMaterial({ color: 0xff2d2d }));
  tally.position.set(0, 1.74, 0.3);
  g.add(body, lens, hood, viewfinder, head, tally);
  return { group: g, tally };
}

/** Plató de entrevista: reportero con micro, operador, cámara de TV, fondo y cartel ON AIR. */
export function buildInterviewSet(): InterviewSet {
  const group = new THREE.Group();

  const backdrop = box(5.4, 2.6, 0.12, 0x111827);
  backdrop.position.set(9.5, 1.3, 11.3);
  const stripe = box(5.4, 0.16, 0.14, 0xff6a1a);
  stripe.position.set(9.5, 2.1, 11.3);

  const airTex = canvasTexture(256, 96, (g) => {
    g.fillStyle = '#7f1d1d';
    g.fillRect(0, 0, 256, 96);
    g.fillStyle = '#ffffff';
    g.font = 'bold 56px sans-serif';
    g.textAlign = 'center';
    g.textBaseline = 'middle';
    g.fillText('ON AIR', 128, 52);
  });
  const onAir = new THREE.Mesh(
    new THREE.BoxGeometry(1.1, 0.4, 0.1),
    new THREE.MeshStandardMaterial({ map: airTex, emissive: 0xff2d2d, emissiveMap: airTex, emissiveIntensity: 0.2 }),
  );
  onAir.position.set(9.5, 2.95, 11.2);

  const reporter = buildHuman({ skin: 0xd9a066, hair: 0x1f1b16, jersey: 0x1e3a8a, shorts: 0x1e293b, shoes: 0x0f172a });
  reporter.root.position.set(9.0, 0, 9.7);
  reporter.root.rotation.y = Math.PI; // mira hacia -Z (la cancha)
  const mic = new THREE.Group();
  mic.add(box(0.03, 0.2, 0.03, 0x111111));
  const micHead = new THREE.Mesh(new THREE.SphereGeometry(0.055, 8, 6), mat(0xf97316));
  micHead.position.y = 0.12;
  mic.add(micHead);
  mic.position.set(0, -0.6, 0.06);
  reporter.armR.add(mic);

  const cam = buildTvCamera();
  cam.group.position.set(11.0, 0, 8.7);
  cam.group.rotation.y = -Math.PI / 2; // apunta hacia -X (el punto de entrevista)

  const operator = buildHuman({ skin: 0xc68642, hair: 0x2b1d12, jersey: 0x111827, shorts: 0x374151, shoes: 0x111827 });
  operator.root.position.set(11.9, 0, 8.7);
  operator.root.rotation.y = -Math.PI / 2;

  group.add(backdrop, stripe, onAir, reporter.root, cam.group, operator.root);
  return { group, reporter, operator, tally: cam.tally, onAir };
}
