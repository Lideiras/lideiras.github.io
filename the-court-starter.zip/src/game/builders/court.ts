import * as THREE from 'three';
import { COURT } from '../config';
import { box, canvasTexture, mulberry32 } from './util';

const PPM = 80; // píxeles de textura por metro

function drawCourt(g: CanvasRenderingContext2D, W: number, H: number, brand: string): void {
  // Parqué
  g.fillStyle = '#c98b4b';
  g.fillRect(0, 0, W, H);
  const plank = PPM * 0.25;
  for (let i = 0, n = 0; i < W; i += plank, n++) {
    g.fillStyle = n % 2 ? 'rgba(0,0,0,0.05)' : 'rgba(255,255,255,0.05)';
    g.fillRect(i, 0, plank, H);
  }
  // Zonas pintadas (4.9 m ancho × 5.8 m largo)
  const keyL = 5.8 * PPM;
  const keyW = 4.9 * PPM;
  g.fillStyle = '#9d3b2a';
  g.fillRect(0, H / 2 - keyW / 2, keyL, keyW);
  g.fillRect(W - keyL, H / 2 - keyW / 2, keyL, keyW);

  // Líneas
  const lw = 0.06 * PPM;
  g.strokeStyle = '#ffffff';
  g.lineWidth = lw;
  g.lineJoin = 'round';
  g.strokeRect(lw / 2, lw / 2, W - lw, H - lw);
  g.beginPath();
  g.moveTo(W / 2, 0);
  g.lineTo(W / 2, H);
  g.stroke();
  g.beginPath();
  g.arc(W / 2, H / 2, 1.8 * PPM, 0, Math.PI * 2);
  g.stroke();

  const hoopFromBase = 1.575 * PPM;
  const arcR = 6.75 * PPM;
  const cornerZ = 6.6 * PPM; // línea de triple a 0.9 m de la banda
  const a = Math.asin(cornerZ / arcR);
  const dxArc = Math.sqrt(arcR * arcR - cornerZ * cornerZ);

  for (const side of [-1, 1] as const) {
    const baseX = side === -1 ? 0 : W;
    const dir = side === -1 ? 1 : -1; // hacia el interior de la pista
    const hx = baseX + dir * hoopFromBase;
    // Caja de la zona + círculo de tiros libres
    g.strokeRect(side === -1 ? 0 : W - keyL, H / 2 - keyW / 2, keyL, keyW);
    g.beginPath();
    g.arc(baseX + dir * keyL, H / 2, 1.8 * PPM, 0, Math.PI * 2);
    g.stroke();
    // Triple: dos rectas + arco
    g.beginPath();
    g.moveTo(baseX, H / 2 - cornerZ);
    g.lineTo(hx + dir * dxArc, H / 2 - cornerZ);
    g.moveTo(baseX, H / 2 + cornerZ);
    g.lineTo(hx + dir * dxArc, H / 2 + cornerZ);
    g.stroke();
    g.beginPath();
    if (side === -1) g.arc(hx, H / 2, arcR, -a, a);
    else g.arc(hx, H / 2, arcR, Math.PI - a, Math.PI + a);
    g.stroke();
    // Semicírculo bajo el aro
    g.beginPath();
    g.arc(hx, H / 2, 1.25 * PPM, side === -1 ? -Math.PI / 2 : Math.PI / 2, side === -1 ? Math.PI / 2 : -Math.PI / 2 + Math.PI * 2, false);
    g.stroke();
  }

  // Marca central
  g.fillStyle = 'rgba(255,255,255,0.92)';
  g.font = `${1.1 * PPM}px "Bebas Neue", Impact, sans-serif`;
  g.textAlign = 'center';
  g.textBaseline = 'middle';
  g.fillText(brand, W / 2, H / 2 + 0.05 * PPM);
}

function buildStands(): THREE.Group {
  const g = new THREE.Group();
  const rows = 6;
  const cols = 40;
  for (let i = 0; i < rows; i++) {
    const step = box(46, 0.6, 1.2, i % 2 ? 0x25304a : 0x2c3957);
    step.position.set(0, 0.3 + i * 0.6, -10.6 - i * 1.2);
    g.add(step);
  }
  const rnd = mulberry32(7);
  const palette = [0xf97316, 0x38bdf8, 0xf8fafc, 0xfacc15, 0xa78bfa, 0x34d399].map((c) => new THREE.Color(c));
  const fans = new THREE.InstancedMesh(
    new THREE.BoxGeometry(0.34, 0.5, 0.34),
    new THREE.MeshStandardMaterial({ color: 0xffffff, flatShading: true }),
    rows * cols,
  );
  const m = new THREE.Matrix4();
  let k = 0;
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      if (rnd() < 0.2) m.makeScale(0.001, 0.001, 0.001); // asiento vacío
      else m.makeTranslation(-19.5 + c + rnd() * 0.2, 0.6 + r * 0.6 + 0.25, -10.6 - r * 1.2);
      fans.setMatrixAt(k, m);
      fans.setColorAt(k, palette[Math.floor(rnd() * palette.length)]!);
      k++;
    }
  }
  fans.instanceMatrix.needsUpdate = true;
  if (fans.instanceColor) fans.instanceColor.needsUpdate = true;
  g.add(fans);
  return g;
}

export function buildCourt(brand: string, maxAnisotropy: number): THREE.Group {
  const group = new THREE.Group();
  const W = COURT.length * PPM;
  const H = COURT.width * PPM;
  const tex = canvasTexture(W, H, (g) => drawCourt(g, W, H, brand));
  tex.anisotropy = maxAnisotropy;

  const floor = new THREE.Mesh(
    new THREE.PlaneGeometry(COURT.length, COURT.width),
    new THREE.MeshStandardMaterial({ map: tex, roughness: 0.55 }),
  );
  floor.rotation.x = -Math.PI / 2;
  floor.receiveShadow = true;

  const around = new THREE.Mesh(
    new THREE.PlaneGeometry(60, 40),
    new THREE.MeshStandardMaterial({ color: 0x1d2433, roughness: 0.9 }),
  );
  around.rotation.x = -Math.PI / 2;
  around.position.y = -0.01;
  around.receiveShadow = true;

  group.add(around, floor, buildStands());
  return group;
}
