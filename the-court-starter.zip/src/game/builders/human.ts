import * as THREE from 'three';
import { box, canvasTexture } from './util';

export interface HumanOptions {
  skin: number;
  hair: number;
  jersey: number;
  shorts: number;
  shoes: number;
  number?: string;
}

export interface HumanRig {
  root: THREE.Group; // posición/rotación en el mundo (pies en y=0, mira hacia +Z local)
  body: THREE.Group; // sube y baja al correr
  torso: THREE.Mesh;
  armL: THREE.Group; // pivotes en los hombros
  armR: THREE.Group;
  legL: THREE.Group; // pivotes en las caderas
  legR: THREE.Group;
}

/** Humanoide low-poly de ~1.9 m construido solo con cajas. Sin assets externos. */
export function buildHuman(o: HumanOptions): HumanRig {
  const root = new THREE.Group();
  const body = new THREE.Group();
  root.add(body);

  const leg = (x: number): THREE.Group => {
    const pivot = new THREE.Group();
    pivot.position.set(x, 0.95, 0);
    const l = box(0.14, 0.9, 0.14, o.skin);
    l.position.y = -0.45;
    const shoe = box(0.16, 0.09, 0.27, o.shoes);
    shoe.position.set(0, -0.86, 0.05);
    pivot.add(l, shoe);
    return pivot;
  };
  const arm = (x: number): THREE.Group => {
    const pivot = new THREE.Group();
    pivot.position.set(x, 1.5, 0);
    const a = box(0.1, 0.58, 0.1, o.skin);
    a.position.y = -0.29;
    const shoulder = box(0.13, 0.14, 0.13, o.jersey);
    shoulder.position.y = -0.04;
    pivot.add(a, shoulder);
    return pivot;
  };

  const legL = leg(-0.11);
  const legR = leg(0.11);
  const armL = arm(-0.29);
  const armR = arm(0.29);

  const shorts = box(0.42, 0.34, 0.26, o.shorts);
  shorts.position.y = 0.98;
  const torso = box(0.44, 0.6, 0.25, o.jersey);
  torso.position.y = 1.27;
  const neck = box(0.08, 0.08, 0.08, o.skin);
  neck.position.y = 1.6;
  const head = box(0.24, 0.26, 0.24, o.skin);
  head.position.y = 1.76;
  const hair = box(0.26, 0.1, 0.26, o.hair);
  hair.position.y = 1.9;
  const eyeL = box(0.03, 0.03, 0.01, 0x111111);
  eyeL.position.set(-0.055, 1.78, 0.121);
  const eyeR = eyeL.clone();
  eyeR.position.x = 0.055;

  body.add(legL, legR, armL, armR, shorts, torso, neck, head, hair, eyeL, eyeR);

  if (o.number) {
    const text = o.number;
    const tex = canvasTexture(128, 128, (g) => {
      g.clearRect(0, 0, 128, 128);
      g.fillStyle = '#ffffff';
      g.font = 'bold 96px Impact, "Bebas Neue", sans-serif';
      g.textAlign = 'center';
      g.textBaseline = 'middle';
      g.fillText(text, 64, 70);
    });
    const plane = new THREE.Mesh(
      new THREE.PlaneGeometry(0.26, 0.26),
      new THREE.MeshBasicMaterial({ map: tex, transparent: true }),
    );
    plane.position.set(0, 1.3, -0.127);
    plane.rotation.y = Math.PI; // el plano mira hacia -Z (la espalda)
    body.add(plane);
  }

  return { root, body, torso, armL, armR, legL, legR };
}

/** Ciclo de carrera procedural. speed01 ∈ [0, 1]. */
export function animateHuman(rig: HumanRig, time: number, speed01: number, holdingBall: boolean): void {
  const swing = Math.sin(time * 11) * 0.9 * speed01;
  rig.legL.rotation.x = swing;
  rig.legR.rotation.x = -swing;
  if (holdingBall) {
    rig.armL.rotation.x = -0.9 - swing * 0.1;
    rig.armR.rotation.x = -0.9 + swing * 0.1;
  } else {
    rig.armL.rotation.x = -swing * 0.8;
    rig.armR.rotation.x = swing * 0.8;
  }
  rig.body.position.y = Math.abs(Math.sin(time * 11)) * 0.06 * speed01;
  rig.torso.scale.y = 1 + Math.sin(time * 2.2) * 0.012;
}

/** Brazos arriba al cargar el tiro. k ∈ [0, 1]. */
export function poseShoot(rig: HumanRig, k: number): void {
  const a = -1.2 - k * 1.3;
  rig.armL.rotation.x = a;
  rig.armR.rotation.x = a;
}
