import type { SectionId } from '../data/content';

export const G = 9.81;
export const COURT = { length: 28, width: 15, halfL: 14, halfW: 7.5 } as const;
export const RIM = { y: 3.05, radius: 0.225, tube: 0.012, fromBaseline: 1.575, boardFromBaseline: 1.2 } as const;
export const BALL = { radius: 0.12, visualScale: 1.5 } as const;
export const SCORE_RADIUS = 0.2; // tolerancia (m) del centro de la canasta; más alto = más fácil
export const SHOOT_RANGE = 11; // distancia máxima "recomendada" al aro
export const METER_HZ = 0.7; // barridos completos (0→1→0) por segundo: más bajo = más fácil
export const SWEET_SPOT = 0.3; // |e| <= 0.3 = zona verde (30 % del medidor): canasta garantizada

export const PLAYER = {
  speed: 5.2,
  bounds: { minX: -16, maxX: 16, minZ: -8.8, maxZ: 10.6 },
} as const;

export const CAMERA = {
  fov: 32,
  offset: [0, 14, 12] as const,
  lerp: 4,
  clampX: 11,
  minZ: -4,
  maxZ: 5,
} as const;

export type Side = -1 | 1;
export const rimX = (s: Side): number => s * (COURT.halfL - RIM.fromBaseline); // ±12.425
export const boardX = (s: Side): number => s * (COURT.halfL - RIM.boardFromBaseline); // ±12.8

export const SECTION_IDS: SectionId[] = ['projects', 'skills', 'about', 'experience', 'contact'];

export interface Zone {
  id: SectionId;
  kind: 'shoot' | 'walk' | 'interview';
  x: number;
  z: number;
  radius: number;
  side?: Side;
}

export const ZONES: Zone[] = [
  { id: 'projects', kind: 'shoot', x: rimX(-1), z: 0, radius: 4.5, side: -1 },
  { id: 'skills', kind: 'shoot', x: rimX(1), z: 0, radius: 4.5, side: 1 },
  { id: 'about', kind: 'walk', x: 0, z: 8.4, radius: 2.4 },
  { id: 'experience', kind: 'walk', x: -10, z: -8.2, radius: 1.8 },
  { id: 'contact', kind: 'interview', x: 9, z: 8.3, radius: 1.6 },
];

export const INTERVIEW = {
  playerSpot: [9, 8.3] as const,
  cameraPos: [5.4, 2.1, 8.9] as const,
  cameraLook: [9.2, 1.3, 9.0] as const,
};
