import type { L10n } from '../i18n';

export type SectionId = 'projects' | 'skills' | 'about' | 'experience' | 'contact';

export interface Link { label: L10n; url: string }

export interface Project {
  id: string;
  title: string;
  year: number;
  summary: L10n;
  stack: string[];
  links: Link[];
}

export interface SkillGroup {
  id: string;
  name: L10n;
  items: { name: string; level: 1 | 2 | 3 | 4 | 5 }[];
}

export interface TimelineItem {
  id: string;
  kind: 'work' | 'education' | 'sport';
  title: L10n;
  org: string;
  start: string;
  end: string | null; // null = actualidad
  description: L10n;
}

export interface Content {
  person: {
    name: string;
    initials: string;
    jerseyNumber: string;
    role: L10n;
    tagline: L10n;
    location: string;
    email: string;
    social: Link[];
  };
  about: { paragraphs: L10n[]; highlights: { label: L10n; value: L10n }[] };
  projects: Project[];
  skills: SkillGroup[];
  timeline: TimelineItem[];
}

/* Datos de ejemplo: la Fase 0 del plan los sustituye por los de tu portfolio actual. */
export const content: Content = {
  person: {
    name: 'Tu Nombre',
    initials: 'TN',
    jerseyNumber: '23',
    role: { es: 'Desarrollador Full Stack', en: 'Full Stack Developer' },
    tagline: {
      es: 'Videojuegos, web y baloncesto.',
      en: 'Games, web and basketball.',
    },
    location: 'Barcelona',
    email: 'hola@example.com',
    social: [
      { label: { es: 'GitHub', en: 'GitHub' }, url: 'https://github.com/' },
      { label: { es: 'LinkedIn', en: 'LinkedIn' }, url: 'https://www.linkedin.com/' },
    ],
  },
  about: {
    paragraphs: [
      {
        es: 'Soy desarrollador full stack con formación en desarrollo de videojuegos.',
        en: 'I am a full stack developer trained in game development.',
      },
    ],
    highlights: [
      { label: { es: 'Posición', en: 'Position' }, value: { es: 'Base', en: 'Point guard' } },
    ],
  },
  projects: [
    {
      id: 'proyecto-ejemplo',
      title: 'Proyecto de ejemplo',
      year: 2025,
      summary: { es: 'Descripción breve del proyecto.', en: 'Short project description.' },
      stack: ['TypeScript', 'Node.js'],
      links: [{ label: { es: 'Código', en: 'Code' }, url: 'https://github.com/' }],
    },
  ],
  skills: [
    {
      id: 'frontend',
      name: { es: 'Frontend', en: 'Frontend' },
      items: [
        { name: 'TypeScript', level: 5 },
        { name: 'Three.js', level: 4 },
      ],
    },
  ],
  timeline: [
    {
      id: 'estudios-videojuegos',
      kind: 'education',
      title: { es: 'Desarrollo de videojuegos', en: 'Game development' },
      org: 'Centro de estudios',
      start: '2019',
      end: '2023',
      description: { es: 'Formación en diseño y programación de videojuegos.', en: 'Training in game design and programming.' },
    },
  ],
};
