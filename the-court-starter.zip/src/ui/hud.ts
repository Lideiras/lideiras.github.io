import type { SectionId } from '../data/content';
import { SECTION_IDS, SWEET_SPOT } from '../game/config';
import type { Input } from '../game/input';
import { getLang, setLang, t, type UIKey } from '../i18n';
import { esc, sectionKey } from './panels';

export interface HudCallbacks {
  onMenuSelect(id: SectionId): void;
  onToggleMute(): boolean; // devuelve el nuevo estado muted
}

export class Hud {
  private labels = new Map<string, { el: HTMLElement; key: UIKey }>();
  private prompt!: HTMLElement;
  private meter!: HTMLElement;
  private needle!: HTMLElement;
  private toastEl!: HTMLElement;
  private live!: HTMLElement;
  private progress!: HTMLElement;
  private menu!: HTMLElement;
  private muteBtn!: HTMLButtonElement;
  private toastTimer = 0;
  private progressValue = 0;
  private muted: boolean;

  constructor(private root: HTMLElement, private cb: HudCallbacks, muted: boolean) {
    this.muted = muted;
    this.root.innerHTML = `
      <div class="hud">
        <div class="hud__top">
          <span class="chip" data-progress></span>
          <div class="hud__buttons">
            <button type="button" class="icon" data-mute></button>
            <button type="button" class="icon" data-lang></button>
            <button type="button" class="icon" data-menu-btn aria-haspopup="true" aria-expanded="false"></button>
          </div>
        </div>
        <nav class="menu" data-menu hidden></nav>
        <div class="hud__labels" data-labels></div>
        <div class="prompt" data-prompt hidden></div>
        <div class="meter" data-meter hidden aria-hidden="true"><i class="sweet" style="left:${((0.5 - SWEET_SPOT / 2) * 100).toFixed(1)}%;width:${(SWEET_SPOT * 100).toFixed(1)}%"></i><b class="needle" data-needle></b></div>
        <div class="toast" data-toast hidden></div>
        <div class="sr-only" data-live aria-live="polite"></div>
      </div>`;
    const q = <T extends HTMLElement>(s: string): T => this.root.querySelector<T>(s)!;
    this.prompt = q('[data-prompt]');
    this.meter = q('[data-meter]');
    this.needle = q('[data-needle]');
    this.toastEl = q('[data-toast]');
    this.live = q('[data-live]');
    this.progress = q('[data-progress]');
    this.menu = q('[data-menu]');
    this.muteBtn = q<HTMLButtonElement>('[data-mute]');

    q('[data-lang]').addEventListener('click', () => setLang(getLang() === 'es' ? 'en' : 'es'));
    this.muteBtn.addEventListener('click', () => {
      this.muted = this.cb.onToggleMute();
      this.refreshText();
    });
    const menuBtn = q<HTMLButtonElement>('[data-menu-btn]');
    menuBtn.addEventListener('click', () => {
      const open = this.menu.hidden;
      this.menu.hidden = !open;
      menuBtn.setAttribute('aria-expanded', String(open));
    });
    this.menu.addEventListener('click', (e) => {
      const b = (e.target as HTMLElement).closest<HTMLElement>('[data-section]');
      if (!b) return;
      this.menu.hidden = true;
      menuBtn.setAttribute('aria-expanded', 'false');
      this.cb.onMenuSelect(b.dataset.section as SectionId);
    });
    window.addEventListener('langchange', () => this.refreshText());
    this.refreshText();
  }

  private refreshText(): void {
    const q = (s: string): HTMLElement => this.root.querySelector<HTMLElement>(s)!;
    q('[data-lang]').textContent = getLang() === 'es' ? 'EN' : 'ES';
    q('[data-lang]').setAttribute('aria-label', t('lang_toggle'));
    this.muteBtn.textContent = this.muted ? '🔇' : '🔊';
    this.muteBtn.setAttribute('aria-label', this.muted ? t('unmute') : t('mute'));
    const mb = q('[data-menu-btn]');
    mb.textContent = '☰';
    mb.setAttribute('aria-label', t('menu'));
    this.menu.innerHTML =
      `<p class="menu__title">${esc(t('menu_title'))}</p>` +
      SECTION_IDS.map((id) => `<button type="button" data-section="${id}">${esc(t(sectionKey(id)))}</button>`).join('') +
      `<a href="/classic/">${esc(t('classic'))}</a>`;
    this.progress.textContent = `${t('progress')} ${this.progressValue}/${SECTION_IDS.length}`;
    for (const { el, key } of this.labels.values()) el.textContent = t(key);
  }

  addLabel(id: string, key: UIKey): void {
    const el = document.createElement('div');
    el.className = 'label';
    el.textContent = t(key);
    this.root.querySelector('[data-labels]')!.appendChild(el);
    this.labels.set(id, { el, key });
  }

  placeLabel(id: string, x: number, y: number, visible: boolean): void {
    const l = this.labels.get(id);
    if (!l) return;
    l.el.style.display = visible ? '' : 'none';
    l.el.style.transform = `translate(-50%, -100%) translate(${x.toFixed(1)}px, ${y.toFixed(1)}px)`;
  }

  setProgress(n: number): void {
    this.progressValue = n;
    this.progress.textContent = `${t('progress')} ${n}/${SECTION_IDS.length}`;
  }

  setPrompt(text: string | null): void {
    this.prompt.hidden = text === null;
    if (text !== null && this.prompt.textContent !== text) this.prompt.textContent = text;
  }

  showMeter(value: number | null): void {
    this.meter.hidden = value === null;
    if (value !== null) this.needle.style.left = `${(value * 100).toFixed(1)}%`;
  }

  toast(text: string, ms = 2400): void {
    this.toastEl.textContent = text;
    this.toastEl.hidden = false;
    this.live.textContent = text;
    window.clearTimeout(this.toastTimer);
    this.toastTimer = window.setTimeout(() => (this.toastEl.hidden = true), ms);
  }

  /** Joystick virtual + botones TIRO / ACCIÓN para pantallas táctiles. */
  mountTouch(input: Input): void {
    const wrap = document.createElement('div');
    wrap.className = 'touch';
    wrap.innerHTML = `
      <div class="joy" data-joy><div class="stick" data-stick></div></div>
      <div class="touch__btns">
        <button type="button" class="btn-round" data-act>E</button>
        <button type="button" class="btn-round btn-round--big" data-shoot>🏀</button>
      </div>`;
    this.root.appendChild(wrap);

    const joy = wrap.querySelector<HTMLElement>('[data-joy]')!;
    const stick = wrap.querySelector<HTMLElement>('[data-stick]')!;
    const R = 48;
    let pid: number | null = null;
    const set = (e: PointerEvent): void => {
      const r = joy.getBoundingClientRect();
      let dx = e.clientX - (r.left + r.width / 2);
      let dy = e.clientY - (r.top + r.height / 2);
      const len = Math.hypot(dx, dy);
      if (len > R) {
        dx = (dx / len) * R;
        dy = (dy / len) * R;
      }
      stick.style.transform = `translate(${dx}px, ${dy}px)`;
      input.joy = { x: dx / R, y: dy / R };
    };
    const end = (): void => {
      pid = null;
      stick.style.transform = '';
      input.joy = { x: 0, y: 0 };
    };
    joy.addEventListener('pointerdown', (e) => {
      pid = e.pointerId;
      joy.setPointerCapture(pid);
      set(e);
    });
    joy.addEventListener('pointermove', (e) => pid === e.pointerId && set(e));
    joy.addEventListener('pointerup', end);
    joy.addEventListener('pointercancel', end);

    const shoot = wrap.querySelector<HTMLElement>('[data-shoot]')!;
    shoot.addEventListener('pointerdown', (e) => {
      e.preventDefault();
      input.shootHeld = true;
    });
    for (const ev of ['pointerup', 'pointercancel', 'pointerleave'] as const) shoot.addEventListener(ev, () => (input.shootHeld = false));
    wrap.querySelector<HTMLElement>('[data-act]')!.addEventListener('pointerdown', (e) => {
      e.preventDefault();
      input.pressInteract();
    });
  }
}
